
package com.bookstore.java.service.impl.test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;

import com.bookstore.java.dto.BookRequestDto;
import com.bookstore.java.dto.BookResponseDto;
import com.bookstore.java.entity.Book;
import com.bookstore.java.exception.BookNotFoundException;
import com.bookstore.java.repository.BookRepository;
import com.bookstore.java.service.impl.BookServiceImpl;

import static org.mockito.ArgumentMatchers.any;

import static org.junit.jupiter.api.Assertions.assertTrue;

@ExtendWith(MockitoExtension.class)
public class BookServiceImplTest {

	@Mock
	BookRepository bookRepository;

	@InjectMocks
	BookServiceImpl bookServiceImpl;

	Book book;
	BookRequestDto bookRequestDto;
	BookResponseDto bookResponseDto;

	Book savedBook;

	@BeforeEach
	public void setUp() {
		bookRequestDto = new BookRequestDto();
		bookRequestDto.setBookName("Complete Referance Java");
		bookRequestDto.setAuthor("Herbert Schildt");
		bookRequestDto.setGenre("Educational");
		bookRequestDto.setPrice(500);
		bookRequestDto.setRating(4);

		book = new Book();
		book.setBookId(1);
		book.setBookName("C Programming");
		book.setAuthor("Yashwant Kanedkar");
		book.setGenre("Educational");
		book.setPrice(500);
		book.setRating(4);

		savedBook = new Book();
		BeanUtils.copyProperties(book, savedBook);

	}

	@Test

	@DisplayName("Save Book Data:Positive")
	public void addBookTest_Positive() {

		// context

		when(bookRepository.save(any(Book.class))).thenReturn(savedBook);

		// event
		boolean result = bookServiceImpl.addBook(bookRequestDto);

		// outcome
		assertTrue(result);

	}

	@Test
	@DisplayName("find Book By Id Test:Positive")
	public void getBookByIdTest_Positive() throws BookNotFoundException {
// context

		when(bookRepository.findById(1)).thenReturn(Optional.of(book));

// event
		BookResponseDto result = bookServiceImpl.getBookById(1);

// outcome
		assertEquals("C Programming", result.getBookName());

	}

	@Test
	@DisplayName("find Customer By Id Test:Negative")
	public void getBookByIdTest_Negative() {
// context

		when(bookRepository.findById(1)).thenReturn(null);

		NullPointerException e = assertThrows(NullPointerException.class, () -> {
			bookServiceImpl.getBookById(1);
		});

// outcome
		assertEquals(NullPointerException.class, e.getClass());

	}

}
