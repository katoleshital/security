package com.bookstore.java.service;

import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.util.List;

import javax.validation.Valid;

import com.bookstore.java.dto.BookRequestDto;
import com.bookstore.java.dto.BookResponseDto;
import com.bookstore.java.dto.BookResponseProj;

public interface BookService {

	boolean addBook(BookRequestDto bookRequestDto);

	List<BookResponseDto> getAllBooks();

	BookResponseDto getBookById(Integer bookId);

	BookResponseDto getBookByName(String bookName);

	BookResponseDto findByGenre(String genre);

	void updateBook(BookRequestDto bookRequestDto, Integer bookId);

	void deleteBook(Integer bookId);

}
