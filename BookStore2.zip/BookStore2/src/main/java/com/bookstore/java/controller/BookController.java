package com.bookstore.java.controller;

import java.util.List;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bookstore.java.dto.BookRequestDto;
import com.bookstore.java.dto.BookResponseDto;
import com.bookstore.java.exception.BookNotFoundException;
import com.bookstore.java.service.BookService;

@RestController
@Validated
public class BookController {

	@Autowired
	BookService bookService;

	@PostMapping("/books")
	public ResponseEntity<String> addBook(@RequestBody BookRequestDto bookRequestDto) {
		boolean response = bookService.addBook(bookRequestDto);
		if (response)
			return new ResponseEntity<String>("Book Data saved successfully", HttpStatus.ACCEPTED);
		return new ResponseEntity<String>("Book Data saved successfully", HttpStatus.NOT_ACCEPTABLE);

	}

	@GetMapping("/books")
	public ResponseEntity<List<BookResponseDto>> getAllBooks() {
		return new ResponseEntity<List<BookResponseDto>>(bookService.getAllBooks(), HttpStatus.OK);
	}

	@GetMapping("/books/{bookId}")
	public ResponseEntity<BookResponseDto> getBookById(
			@NotNull(message = "Book Id can't be Empty") @PathVariable Integer bookId) {
		return new ResponseEntity<BookResponseDto>(bookService.getBookById(bookId), HttpStatus.OK);
	}

	@GetMapping("/books/bookname")
	public ResponseEntity<BookResponseDto> getBookItemByName(
			@NotEmpty(message = "bookname can't be empty") @RequestParam String bookName) {
		return new ResponseEntity<BookResponseDto>(bookService.getBookByName(bookName), HttpStatus.OK);
	}

	@GetMapping("/books/bookgenre")
	public ResponseEntity<BookResponseDto> getBookItemByGenre(
			@NotEmpty(message = "genre can't be empty") @RequestParam String genre) {
		return new ResponseEntity<BookResponseDto>(bookService.findByGenre(genre), HttpStatus.ACCEPTED);
	}

	@PutMapping(value = "/books/{bookId}")
	public String updateBook(@RequestBody BookRequestDto BookRequestDto, @PathVariable Integer bookId) {
		bookService.updateBook(BookRequestDto, bookId);
		return "book data updated successfully";
	}

	@DeleteMapping("/books/{bookId}")
	public ResponseEntity<String> deleteBookById(@PathVariable Integer bookId) {
		bookService.deleteBook(bookId);
		return new ResponseEntity<String>("book deleted successfully", HttpStatus.OK);
	}
}
