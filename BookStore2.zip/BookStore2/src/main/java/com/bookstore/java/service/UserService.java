package com.bookstore.java.service;

import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import com.bookstore.java.dto.UserRequestDto;
import com.bookstore.java.dto.UserResponseDto;
import com.bookstore.java.entity.User;

public interface UserService {

	// public UserResponseDto login(UserRequestDto RequestDto);
	public void registerUser(User user);

}
